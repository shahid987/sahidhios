import UIKit

var greeting = "Hello, playground"

func greetUser(){
                print("Welcome User")
    }


