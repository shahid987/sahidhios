//
//  ViewController.swift
//  Manyam_GroceryApp
//
//  Created by Manyam,Siva Rama Krishna on 4/5/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController {

    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

